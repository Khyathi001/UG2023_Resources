A = 5;
fo = 20;
Samp = 1000; 
t = 0:1/Samp:1;

x_t = A * sin(2 * pi * fo * t);

X_f = fftshift(fft(x_t));

f = -Samp/2: Samp/length(X_f) :Samp/2-Samp/length(X_f); 

figure;

real = real(X_f);
imag = imag(X_f);
magn = abs(X_f);
angl = angle(X_f);

subplot(2, 2, 1);
plot(f, real);
title('Real Part of X(f)');
xlabel('frequency (Hz)');
ylabel('amplitude');
grid on;

subplot(2, 2, 2);
plot(f, imag);
title('Imaginary Part of X(f)');
xlabel('frequency (Hz)');
ylabel('amplitude');
grid on;

subplot(2, 2, 3);
plot(f, magn);
title('Magnitude of X(f) ');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;

subplot(2, 2, 4);
plot(f, angl);
title('Phase of X(f)');
xlabel('Frequency (Hz)');
ylabel('Phase (radians)');
grid on;

sgtitle('Analysis Fourier Transform of x(t)');


