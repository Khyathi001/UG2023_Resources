fs = 1000; 
t = -1:1/fs:1-1/fs; 
x = sin(pi * t)/ pi .* t;

X_f = fftshift(fft(x));
f = (-fs/2:fs/length(X_f):fs/2-fs/length(X_f));

fc = 10;
x1 = exp(1i*2*pi*fc*t) .* x;
X1 = fftshift(fft(x1));

A = 20;
x2 = sin(pi * (t/A)) / pi .* (t/A);
X2 = fftshift(fft(x2));

x3 = x.^2;
X3 = fftshift(fft(x3));

figure;

subplot(2,2,1);
plot(f, abs(X_f));
title('Fourier Transformation of x(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;

subplot(2,2,2);
plot(f, abs(X1));
title('Fourier Transformation of e^{j2πfct}x(t)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;

subplot(2,2,3);
plot(f, abs(X2));
title('Fourier Transformation of x(t/A)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;

subplot(2,2,4);
plot(f, abs(X3));
title('Fourier Transformation of x(t)^2');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;

sgtitle('Fourier Transform');