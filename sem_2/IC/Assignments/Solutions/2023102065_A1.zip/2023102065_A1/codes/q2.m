Ac = 1;
Am = 2;
fc = 100;
fm = 10;
t = 0:1/1000:1;

m_t = Am * sin(2 * pi * fm * t);
c_t = Ac * cos(2 * pi * fc * t);

x_t = Ac * (1 + Am/Ac * sin(2 * pi * fm * t)) .* cos(2 * pi * fc * t);

M_f = fft(m_t);
C_f = fft(c_t);
X_f = fft(x_t);

f = (-1000/2): (1000/length(X_f)) :(1000/2 - 1000/length(X_f));

figure;

subplot(3, 1, 1);
plot(f, abs(M_f));
title('Magnitude Spectrum of M(f)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');

grid on;


subplot(3, 1, 2);
plot(f, abs(C_f));
title('Magnitude Spectrum of C(f)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;


subplot(3, 1, 3);
plot(f, abs(X_f));
title('Magnitude Spectrum of X(f)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');

grid on;

% We can see that the maximum magnitude of all the Fourier Transforms have
% the same magnitudes but is obtained at differnet frequencies.


