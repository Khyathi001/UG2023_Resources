close all;
t = 0:0.000005:1;
fs = 1/0.000005;

figure;

%(a) Message Signal Analysis

m_t = sin(2*pi*100*t) + sin(2*pi*200*t);

subplot(2, 2, 1);
plot(t, m_t);
title('Plot of m(t)');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0,0.25]);
ylim([-3, 3]);

subplot(2, 2, 2);

M = fft(m_t);
f = linspace(-fs/2, fs/2 - fs/length(M), length(M));

M_f = fftshift(fft(m_t));
plot(f, abs(M_f));
title('Magnitude Spectrum of M(f)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([-300, 300]);

%(b) Carrier Signal Analysis

subplot(2, 2, 3);

c_t = cos(2*pi*1000*t);

plot(t, c_t);
title('Plot of c(t)');
xlabel('Time (s)');
ylabel('Amplitude');
ylim([-2, 2]);
xlim([0, 0.01]);

subplot(2,2,4);

C = fft(c_t);
f1 = linspace(-fs/2, fs/2 - fs/length(C), length(C));
C_f = fftshift(C);
plot(f1, abs(C_f));
title('Magnitude Spectrum of of C(f)');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
ylim([0,100]);
xlim([-2000, 2000]);

figure;

%(c) Amplitude modulation

subplot(2, 2, 1);
u = 0.5; % Modulation index
A_t = (1 + u*m_t).*c_t;

plot(t, A_t);
title('Plot of A(t)');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0,0.05]);
ylim([min(st_am) - 0.5, max(st_am) + 0.5]);

subplot(2,2,2);
A = fft(A_t);
frequencies = linspace(-fs/2, fs/2 - fs/length(A), length(A));
A_f= fftshift(A);
plot(frequencies, abs(A_f));
title('Magnitude Spectrum of AM Signal');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([-2000, 2000]); 

%(d) DSB-SC modulation 

subplot(2, 2, 3);

S_t = m_t .* c_t;

plot(t, S_t);
title('Plot of DSB_SC(t)');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0,0.05]);
ylim([min(st_dsb_sc) - 0.5, max(st_dsb_sc) + 0.5]);

subplot(2, 2, 4);
S = fft(S_t);
frequencies = linspace(-fs/2, fs/2 - fs/length(S), length(S));
S_f = fftshift(S);
plot(frequencies, abs(S_f));
title('Magnitude Spectrum of DSB-SC Signal');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([-2000, 2000]);

% (e) OBSERVATIONS:
% - AM produces sidebands around the carrier frequency by modulating the
% message signal's amplitude with the carrier signal.
% - DSB-SC broadcasts only the sidebands after removing the carrier, which
% aids in the effective use of the available bandwidth.
% When there is a narrowband message signal and the carrier signal needs 
% to be quickly retrieved at the receiver, AM is the best option.
% When bandwidth efficiency is crucial and the demodulation method can 
% effectively recover the message signal from the sidebands, DSB-SC 
% is the recommended option.

